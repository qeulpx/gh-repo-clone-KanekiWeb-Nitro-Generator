<p align='center'>
  <b>🦊 Follow me here 🦊</b><br>  
  <a href="https://discord.gg/kaneki">Discord</a> |
  <a href="https://www.youtube.com/channel/UC-XII5SSqbMOF1UX3N0Gl8g">YouTube</a> |
  <a href="https://github.com/KanekiWeb">Github</a><br><br>
  <img src="https://cdn.discordapp.com/attachments/879708989158490152/883919490402897980/unknown.png" style="width: 60%">
</p>

##  


### ☕ Usage  
- #### 💻 Downloading
     ```
    >> git clone https://github.com/KanekiWeb/Nitro-Generator/new/main
    >> pip install -r requirements.txt
    ```
- #### 🖥️ Starting
      1 - Enter your proxies in config/proxies.txt
      2 - Create Discord Webhook and put link in config/config.json (optional)
      3 - Enter a custom avatar url and username for webhook (optional)
      4 - Select how many thread you want use in config/config.json (optional)
      5 - Run main.py and enjoy checking

##  

### 🏆 Features List
- Very Fast Checking
- Proxy support: http/s, socks4/5, Premium
- Simple Usage
- Custom Thread
- Send hit to webhook

##   

### 🧰 Support
- Email: <kaneki_pro@protonmail.com>
- Discord: https://discord.gg/9YGYfDZAGG

##  

### 📜 License & Warning
- Make for education propose only
- Under licensed MIT MIT License.

##  

<p align="center">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
  <img src="https://badges.frapsoft.com/os/v3/open-source.svg?v=103" alt="Open Source">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=KanekiWeb.Nitro-Generator" alt="Visitor Count">
</p>
